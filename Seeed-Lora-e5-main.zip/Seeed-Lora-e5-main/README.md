Seeed Lora e5 p2p PingPong without seperate MCU

The example is based on the original STM PingPong example (https://github.com/STMicroelectronics/STM32CubeWL/tree/main/Projects/NUCLEO-WL55JC/Applications/SubGHz_Phy/SubGHz_Phy_Per)
The configuration of this project is based on the project of danak6jq (https://github.com/danak6jq/Seeed-LoRa-E5)